####################################
n=100
x=rnorm(n,0,1)
y=x+runif(n)
plot(x,y,col="blue")
fit=lm(y~x)
abline(fit,col="red",lwd=2)

xr=resid(fit)
t(x)%*%xr  should be close to zero
yp=predict(fit)
for (i in 1:length(x))
{
#print(i)
lines(c(x[i],x[i]),c(yp[i],y[i]))
}
points(mean(x), mean(y), cex = 2, bg = "lightblue", col = "black", pch = 21)
###################################
dfbetas(fit)
hatvalues(fit)
x1<-c(1,x)
x1%*%t(x1)
solve(x1%*%t(x1))
fit$coef[1]+fit$coef[2]*x
y
##################################################
x=rnorm(n,2,1)
x[n]=10
y=x+runif(n)
z=x+y+runif(n)
z[10]=100
fit2=lm(z~x+y)
dfbetas(fit2)
hatvalues(fit2)


